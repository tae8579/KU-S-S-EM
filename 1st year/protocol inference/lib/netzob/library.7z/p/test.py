from netzob.all import *

# Import of two PCAP files representing two sessions of the protocol (i.e. two instances of a communication between the client and the server)
messages_session1 = PCAPImporter.readFile("quic.pcap").values()
messages = messages_session1

# Group the messages of the two sessions into a uniq symbol
symbol = Symbol(messages = messages)

# Display symbol content
print(symbol)
