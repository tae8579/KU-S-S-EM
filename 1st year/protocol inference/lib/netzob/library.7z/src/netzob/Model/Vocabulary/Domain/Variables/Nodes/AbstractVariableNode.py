# -*- coding: utf-8 -*-
from netzob.Common.Utils.Decorators import typeCheck
from netzob.Model.Vocabulary.Domain.Variables.AbstractVariable import AbstractVariable


class AbstractVariableNode(AbstractVariable):
    """Represents a node in the variable definition of a field.

    A node is a variable which accepts children, such as Alternate(:class:`netzob.Model.Vocabulary.Variables.Nodes.Alt.Alt`)
    and Aggregate (:class:`netzob.Model.Vocabulary.Variables.Nodes.Agg.Agg`).
    Thus both of them inherits from this.

    """

    def __init__(self, varType, children=None, svas=None):
        super(AbstractVariableNode, self).__init__(varType, svas=svas)
        self._children = []
        if children is not None:
            self.children = children

    @property
    def children(self):
        """Sorted typed list of children attached to the variable node.
        .. warning:: Setting this value with a list copies its members and not the list itself.

        :type: a list of :class:`netzob.Model.Vocabulary.Variables.Variable`

        """
        return self._children

    @children.setter
    def children(self, children):
        from netzob.Model.Vocabulary.Domain.DomainFactory import DomainFactory
        self._children = []
        for child in children:
            normalizedChild = DomainFactory.normalizeDomain(child)
            self._children.append(normalizedChild)

    def _str_debug(self, deepness=0):
        """Returns a string which denotes
        the current field definition using a tree display"""

        tab = ["     " for x in range(deepness - 1)]
        tab.append("|>>   ")
        tab.append("{0}".format(self))
        lines = [''.join(tab)]
        for f in self.children:
            lines.append(" " + f._str_debug(deepness + 1))
        return '\n'.join(lines)
